
test testExample1_1 # runs test for complete mlp scripts
#test testExample1_2 # runs test for complete mlp scripts

#delete('log_test1_1');
#delete('log_test1_2');